<?php $__env->startSection('content'); ?>
<style>
    .table {
        table-layout: fixed !important;
        white-space: inherit;
    }

    table td,
    th {
        word-wrap: break-word;
        overflow: hidden;
        white-space: inherit !important;

    }
</style>
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-folder bg-c-blue"></i>
                <div class="d-inline">
                    <h5><?php echo e(ucwords( Request::segment(1) )); ?></h5>
                    <span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title breadcrumb-padding">
                    <li class="breadcrumb-item">
                        <a href="index.html"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href=""><?php echo e(ucwords( Request::segment(1) )); ?></a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- [ breadcrumb ] end -->
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <!-- [ page content ] start -->
                <div class="card">
                    <div class="card-header bg-light">
                        <div class="d-flex justify-content-between">
                            <h4 class="fw-bold">Bank Data</h4>
                            <a href="<?php echo e(route('bank-data.create')); ?>" class="btn btn-primary"> Tambah Data</a>
                        </div>
                    </div>
                    <div class="card-block">
                        <div class="dt-responsive table-responsive">
                            <table class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th style="width: 2%">#</th>
                                        <th style="width: 5%">Kode Sampel</th>
                                        <th style="width: 3% ">Virus</th>
                                        <th style="width: 4%;">Genotipe dan Subtipe
                                        </th>
                                        <th style="width: 3%">Tanggal</th>
                                        <th style="width: 5%">Tempat</th>
                                        <th style="width: 3%">Gen</th>
                                        <th style="width: 20%;">Data Sekuen</th>
                                        <th style="width: 5%">Judul</th>
                                        <th style="width: 5%">Author</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Kode Sampel</th>
                                        <th>Virus</th>
                                        <th>Genotipe dan Subtipe</th>
                                        <th>Tanggal</th>
                                        <th>Tempat</th>
                                        <th>Gen</th>
                                        <th>Data Sekuen</th>
                                        <th>Judul</th>
                                        <th>Author</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php

                                    $virus =
                                    App\Models\Virus::select('nama_virus')->where('id',$item->id_virus)->pluck('nama_virus')[0];
                                    $genotipe =
                                    App\Models\Genotipe::select('kode_genotipe')->where('id',$item->id_genotipe)->pluck('kode_genotipe')[0];

                                    ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->kode_sampel); ?></td>
                                        <td><?php echo e($virus); ?></td>
                                        <td><?php echo e($genotipe); ?></td>
                                        <td><?php echo e(tanggal_indo($item->tanggal_pengambilan)); ?></td>
                                        <td><?php echo e($item->tempat); ?></td>
                                        <td><?php echo e($item->nama_gen); ?></td>
                                        <td><?php echo e($item->data_sekuen); ?></td>
                                        <td><?php echo e($item->judul_artikel); ?></td>
                                        <td><?php echo e($item->nama_pengarang.';'.$item->anggota); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9" class="text-center"> Data Masih Belum ada</td>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
                <!-- [ page content ] end -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php
function tanggal_indo($tanggal)
{
$bulan = array (1 => 'Januari',
'Februari',
'Maret',
'April',
'Mei',
'Juni',
'Juli',
'Agustus',
'September',
'Oktober',
'November',
'Desember'
);
$split = explode('-', $tanggal);
return $bulan[ (int)$split[1] ] . ' ' . $split[0];
}
?>
<?php echo $__env->make('template.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function () {
        $('.table').DataTable({
            "autoWidth": false,

        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/backend/bank-data/index.blade.php ENDPATH**/ ?>