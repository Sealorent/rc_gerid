<?php $__env->startSection('content'); ?>
<style>
    .table {
        table-layout: fixed !important;
        white-space: inherit;
    }

    table td {
        word-wrap: break-word;
        overflow: hidden;
        white-space: inherit !important;
    }

    table th {
        word-wrap: break-word;
        overflow: hidden;
        white-space: inherit !important;
    }
</style>
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="fa fa-clipboard bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Data Penulis</h5>
                    <span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title breadcrumb-padding">
                    <li class="breadcrumb-item">
                        <a href="index.html"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="">Data Penulis</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="pcoded-inner-content m-0">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <!-- [ page content ] start -->
                <div class="card">
                    <div class="card-header bg-light">
                        <div class="d-flex justify-content-between align-middle">
                            <h6 class="mt-2 fw-bold">Data Penulis</h6>
                            <a href="<?php echo e(route('pengarang.create')); ?>" class="btn btn-primary">Tambah Data</a>
                        </div>
                    </div>
                    <div class="card-block">
                        <div class="dt-responsive table-responsive">
                            <table class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th style="width: 10%">#</th>
                                        <th>Nama Pengarang</th>
                                        <th>Anggota</th>
                                        <th>Alamat</th>
                                        <th>Institusi</th>
                                        <th>Opsi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->nama_pengarang); ?></td>
                                        <td><?php echo e($item->anggota); ?></td>
                                        <td><?php echo e($item->alamat); ?></td>
                                        <td><?php echo e($item->institusi); ?></td>
                                        <th>
                                            <div class="d-flex justify-content-start">
                                                <a href="<?php echo e(route('pengarang.edit', $item->id)); ?>"
                                                    style="margin-right: 0.5em" class="btn btn-primary"><i
                                                        class="fa fa-pencil text-center m-0"></i></a>
                                                <a href="<?php echo e(route('pengarang.show', $item->id)); ?>"
                                                    style="margin-right: 0.5em" class="btn btn-warning"><i
                                                        class="fa fa-eye text-center m-0"></i></a>
                                                <form action="<?php echo e(route('pengarang.destroy',$item->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="sumbit" class="btn btn-danger"
                                                        onclick="return confirm('Are you sure you want to delete this item?');"><i
                                                            class="fa fa-trash text-center m-0"></i></button>
                                                </form>
                                            </div>
                                        </th>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Data Masih Tidak ada</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th style="width: 10%">#</th>
                                        <th>Nama Pengarang</th>
                                        <th>Anggota</th>
                                        <th>Alamat</th>
                                        <th>Intitusi</th>
                                        <th>Opsi</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- [ page content ] end -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function () {
        $('.table').DataTable();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/backend/pengarang/index.blade.php ENDPATH**/ ?>