@php
function tanggal_indo($tanggal) {
$bulan = array (1 => 'Januari',
'Februari',
'Maret',
'April',
'Mei',
'Juni',
'Juli',
'Agustus',
'September',
'Oktober',
'November',
'Desember'
);
$split = explode('-', $tanggal);
return $bulan[ (int)$split[1] ] . ' ' . $split[0];
}
<?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/components/getBulanTahun.blade.php ENDPATH**/ ?>