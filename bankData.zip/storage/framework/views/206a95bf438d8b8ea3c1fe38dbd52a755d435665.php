<?php $__env->startSection('content'); ?>
<style>
    .table {
        table-layout: fixed !important;
        white-space: inherit;
    }

    table td {
        word-wrap: break-word;
        overflow: hidden;
        white-space: inherit !important;
    }

    table th {
        word-wrap: break-word;
        overflow: hidden;
        white-space: inherit !important;
    }

    .loader {
        position: absolute;
        bottom: 12em;
        align-items: center;
        z-index: 99999;
        opacity: 1;
    }
</style>
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="fa fa-globe bg-c-blue"></i>
                <div class="d-inline">
                    <h5><?php echo e(ucwords( Request::segment(1) )); ?></h5>
                    <span>lorem ipsum dolor sit amet, consectetur adipisicing elit</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title breadcrumb-padding">
                    <li class="breadcrumb-item">
                        <a href="index.html"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href=""><?php echo e(ucwords( Request::segment(1) )); ?></a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <!-- [ page content ] start -->
                <div class="card">
                    <div class="card-header bg-light d-flex justify-content-between">
                        <h4 class="fw-bold">Map</h4>
                        <div class="d-flex justify-content-start">
                            <select name="id_virus" id="id_virus"
                                class="form-control  <?php $__errorArgs = ['id_virus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__currentLoopData = $virus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?> ">
                                    <?php echo e($item->nama_virus); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="text" class="form-control  <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date"
                                name="date" style="padding-right: 2em" value="2017-08" placeholder="Bulan & Tahun"
                                required>
                            <button class="btn btn-primary filter">Filter</button>
                        </div>
                    </div>
                    <div class="card-block">
                        <div class="d-flex justify-content-center">
                            <div class="spinner-border text-warning loader" id="spinner" role="status">
                                
                            </div>
                        </div>
                        <div id="map">
                        </div>
                    </div>
                </div>
                <!-- [ page content ] end -->
            </div>
        </div>
    </div>
</div>

<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <!-- [ page content ] start -->
                <div class="card">
                    <div class="card-header bg-light">
                        <div class="d-flex justify-content-between">
                            <h4 class="fw-bold">Data Spasial</h4>
                            <a href="<?php echo e(route('bank-data.create')); ?>" class="btn btn-primary"> Tambah Data</a>
                        </div>
                    </div>
                    <div class="card-block">
                        <div class="dt-responsive table-responsive">
                            <table class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th style="width: 1%">#</th>
                                        <th style="width: 4%">Kode Sampel</th>
                                        <th style="width: 3% ">Virus</th>
                                        <th style="width: 4%;">Genotipe dan Subtipe</th>
                                        <th style="width: 4%">Bulan/Tahun Sampel</th>
                                        <th style="width: 5%;">Tempat Pengambilan</th>
                                        <th style="width: 5%">Kota Pengambilan</th>
                                        <th style="width: 5%">Provinsi Pengambilan</th>
                                        <th style="width: 5%">Opsi</th>
                                    </tr>
                                </thead>
                                <tfoot align="center">
                                    <tr>
                                        <th style="width: 1%">#</th>
                                        <th style="width: 5%">Kode Sampel</th>
                                        <th style="width: 3% ">Virus</th>
                                        <th style="width: 4%;">Genotipe dan Subtipe</th>
                                        <th style="width: 5%">Bulan/Tahun Sampel</th>
                                        <th style="width: 9%;">Tempat Pengambilan</th>
                                        <th style="width: 5%">Kota Pengambilan</th>
                                        <th style="width: 5%">Provinsi Pengambilan</th>
                                        <th style="width: 5%">Opsi</th>
                                    </tr>
                                </tfoot>
                                <tbody align="center">
                                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                    $virus =
                                    App\Models\Virus::select('nama_virus')->where('id',$item->id_virus)->pluck('nama_virus')[0];
                                    $genotipe =
                                    App\Models\Genotipe::select('kode_genotipe')->where('id',$item->id_genotipe)->pluck('kode_genotipe')[0];
                                    ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->kode_sampel); ?>ds<?php echo e($item->id); ?></td>
                                        <td><?php echo e($virus); ?></td>
                                        <td><?php echo e($genotipe); ?></td>
                                        <td><?php echo e(tanggal_indo($item->tanggal_pengambilan)); ?></td>
                                        <td><?php echo e($item->tempat); ?></td>
                                        <td><?php echo e(getKota($item->id_kota)); ?></td>
                                        <td><?php echo e(getProvinsi($item->id_provinsi)); ?></td>
                                        <td>
                                            <div class="d-flex justify-content-start">
                                                <a class="btn btn-primary"
                                                    href="<?php echo e(route('bank-data.edit',$item->id)); ?>"
                                                    style="margin-right: 0.5em"><i
                                                        class="fa fa-pencil text-center m-0"></i>
                                                </a>
                                                <form action="<?php echo e(route('bank-data.destroy', $item->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="submit"
                                                        onclick="return confirm('Are you sure you want to delete this item?');"
                                                        class="btn btn-danger"><i
                                                            class="fa fa-trash text-center m-0"></i></button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">Data Masih Belum ada</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
                <!-- [ page content ] end -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.data-spatial.leaflet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
function tanggal_indo($tanggal)
{
$bulan = array (1 => 'Januari',
'Februari',
'Maret',
'April',
'Mei',
'Juni',
'Juli',
'Agustus',
'September',
'Oktober',
'November',
'Desember'
);
$split = explode('-', $tanggal);
return $bulan[ (int)$split[1] ] . ' ' . $split[0];
}

function getProvinsi($id)
{
$prov = App\Models\Provinsi::where('id', $id)->pluck('nama_provinsi')[0];
return $prov;
}
function getKota($id)
{
$kab = App\Models\Kabupaten::where('id', $id)->pluck('nama_kabupaten')[0];
return $kab;
}
?>
<?php $__env->startPush('js'); ?>


<script>
    $('#date').datepicker({
        autoclose: true,
        viewMode: 'years',
        format: 'yyyy-mm',
        minViewMode: 1,
        zIndexOffset : 99999999,
    });

    $(document).ready(function () {
        $('.table').DataTable({
            "autoWidth": false,
        });
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/backend/data-spatial/index.blade.php ENDPATH**/ ?>