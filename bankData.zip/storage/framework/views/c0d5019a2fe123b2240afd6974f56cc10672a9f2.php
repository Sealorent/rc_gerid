<nav class="pcoded-navbar">
    <div class="nav-list">
        <div class="pcoded-inner-navbar main-menu">
            <ul class="pcoded-item pcoded-left-item">
                <li class="<?php echo e(Request::segment(1) == 'admin-panel' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="fa fa-home"></i>
                        </span>
                        <span class="pcoded-mtext">Dashboard</span>
                    </a>
                </li>
            </ul>
            <div class="pcoded-navigation-label">Master Data</div>
            <ul class="pcoded-item pcoded-left-item">
                <li class="<?php echo e(Request::segment(1) == 'bank-data' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('bank-data.index')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="fa fa-folder"></i>
                        </span>
                        <span class="pcoded-mtext">Bank Data</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::segment(1) == 'data-spasial' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('data-spasial.index')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="fa fa-globe"></i>
                        </span>
                        <span class="pcoded-mtext">Data Spasial</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::segment(1) == 'pengarang' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('pengarang.index')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="fa fa-clipboard"></i>
                        </span>
                        <span class="pcoded-mtext">Data Penulis</span>
                    </a>
                </li>
                <ul class="pcoded-item pcoded-left-item">
                    <li class="pcoded-hasmenu <?php echo e(Request::segment(1) == 'menu' ? 'active pcoded-trigger' : ''); ?>">
                        <a href="javascript:void(0)" class="waves-effect waves-dark">
                            <span class="pcoded-micon"><i class="feather icon-list"></i></span>
                            <span class="pcoded-mtext">Menu</span>
                        </a>
                        <ul class="pcoded-submenu">
                            <li class="<?php echo e(Request::segment(2) == 'virus' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('virus.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Virus</span>
                                </a>
                            </li>
                            <li class="<?php echo e(Request::segment(2) == 'genotipe' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('genotipe.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Genotipe & Subtype</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/template/partials/sidebar.blade.php ENDPATH**/ ?>