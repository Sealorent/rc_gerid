<?php $__env->startSection('content'); ?>
<div class="row mt-5">
    <div class="col-10">
        <h4><?php echo e($data->judul_artikel); ?></h4>
        <p>Kode Sampel: <?php echo e($data->kode_sampel); ?></p>
        <hr>
        <p> ><?php echo e($data->nama_gen); ?></p>
        <div class="col-5">
            <p><?php echo e($data->data_sekuen); ?></p>
        </div>
    </div>
    <div class="col-2">
        <table>
            <tbody>
                <tr>Analyze this Sequence</tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/frontend/detail-fasta.blade.php ENDPATH**/ ?>