<?php $__env->startPush('css'); ?>
<style>
    #map {
        height: 55vh;
        width: 100%;
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/js/custom/leaflet.js')); ?>"></script>
<script type="text/javascript">
    $('#date').datepicker({
        autoclose: true,
        viewMode: 'years',
            format: 'yyyy-mm',
            minViewMode: 1,
        zIndexOffset : 999,
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/frontend/components/leaflet-home.blade.php ENDPATH**/ ?>