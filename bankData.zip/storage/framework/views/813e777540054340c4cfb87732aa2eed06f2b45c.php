<?php $__env->startPush('js'); ?>
<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Sukses',
        text: "<?php echo e(session()->get('success')); ?>",
        showCancelButton: false,
        confirmButtonText: 'OK',
    }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {
        sessionStorage.removeItem('success');
    }
    })

</script>
<?php endif; ?>
<?php if(session('info')): ?>
<script>
    Swal.fire({
        icon: 'info',
        title: 'Mohon Maaf',
        text: "<?php echo e(session()->get('info')); ?>",
        type: "info"
    })
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Terjadi Kesalahan',
        text: "<?php echo e(session()->get('error')); ?>",
        type: "error"
    })
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\SERVER_DOMAINESIA\bankData\resources\views/template/partials/alert.blade.php ENDPATH**/ ?>